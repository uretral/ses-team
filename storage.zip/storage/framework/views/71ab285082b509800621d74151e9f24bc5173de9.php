<section>
    <div class="wide banner">
        <div class="wide-box origin">
            <img src="/storage/<?php echo e($data->banner, false); ?>" alt="banner"/>

            <div id="clock">
                <div>
                    Оставьте заявку в течении
                    <span class="minutes"></span> :
                    <span class="seconds"></span>
                    и получите скидку <span>15%</span>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo \App\Models\Statics\Breadcrumbs::resource($data->name); ?>

<?php echo \App\Models\Statics\Share::block(); ?>


<main>
    <div>
        <div class="wide">
            <div class="wide-content">
                <h1><?php echo e($data->utp, false); ?></h1>
                <h3><?php echo $data->intro; ?></h3>

                <div class="wide-boxes">
                    <div class="wide-boxes-img">
                        <?php if(isset($data->gallery)): ?>
                            <?php $__currentLoopData = $data->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key == 1 || $key == 2): ?>
                                    <div class="wide-boxes-img-frame" style="background-image: url('/storage/<?php echo e($img->img, false); ?>') ">

                                    </div>
                                <?php else: ?>
                                    <img src="/storage/<?php echo e($img->img, false); ?>" alt="img"/>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                    <div class="wide-boxes-text">
                        <?php echo $data->desc; ?>





                        <?php $__currentLoopData = $data->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="price">
                                <div class="price-header">
                                   <p> <?php echo $price->name; ?></p>
                                </div>
                                <div class="price-body">
                                    <?php echo $price->price; ?>

                                </div>
                                <div class="price-footer"></div>
                            </div>
                            <br/>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>











                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php echo $__env->make('blocks.form_home_services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section>
    <div class="half">
        <div class="half-bg">
            <div class="half-bg-img">
                <img src="/storage/<?php echo e($data->steps_img, false); ?>" alt=""/>
            </div>
        </div>
        <div class="half-items">
            <div class="half-item covered">
                <div class="accordion">
                    <?php $__currentLoopData = $data->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($l == 0): ?>
                            <input type="radio" id="type14569_<?php echo e($l, false); ?>" checked name="type_0980"/>
                        <?php else: ?>
                            <input type="radio" id="type14569_<?php echo e($l, false); ?>" name="type_0980"/>
                        <?php endif; ?>
                        <label for="type14569_<?php echo e($l, false); ?>"><?php echo $step->title; ?></label>
                        <div>
                            <p><?php echo $step->text; ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="half-item text">
                <div class="shadow-txt">
                    <?php echo $data->steps_text; ?>

                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div>
        <div class="video">
            <div class="video-video">
                

                <img src="/storage/<?php echo e($data->video_img, false); ?>" alt="image"/>
            </div>
            <div class="video-text">
                <?php echo $data->video_text; ?>

            </div>
        </div>
    </div>
</section>

<section>
    <div>
        <div class="quadro">
            <h2><?php echo $data->libraries_h; ?></h2>
            <div class="quadro-items">
                <?php $__currentLoopData = $data->four; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="quadro-item">
                        <h4><?php echo $libItem->name; ?></h4>
                        <p>
                            <?php echo Str::limit($libItem->intro, 150, '...'); ?>

                            <a href="/articles/<?php echo e($libItem->alias, false); ?>"> Читать далее ></a>
                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="cite">
        <div class="cite-box">
            <h2><?php echo $data->cite_heading; ?></h2>
            <cite>
                <?php echo $data->cite_text; ?>

            </cite>
        </div>
    </div>
</section>
<?php
$texted = \App\Models\Blocks\HalfWithText::where('id',1)->first();
$acces = \App\Models\Blocks\HalfWithAccordion::where('id',4)->first();
?>
<?php echo \App\Models\Blocks\HalfWithText::block($texted,''); ?>

<?php echo \App\Models\Blocks\HalfWithAccordion::block($acces,''); ?>





<section>
    <div>
        <div class="links">
            <div class="links-faq">
                <h2><?php echo $data->ask_h; ?></h2>
                <ul class="links-faqs">
                    <?php if(isset($data->faq)): ?>
                        <?php $__currentLoopData = $data->faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="links-faqs-item">
                                <a href="/articles/<?php echo e($faqItem->alias, false); ?>"><?php echo $faqItem->name; ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="links-more">
                <h2><?php echo $data->lib_heading; ?></h2>
                <ul class="links-items">
                    <?php if(isset($data->common)): ?>
                        <?php $__currentLoopData = $data->common; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="links-item">
                                <a href="/articles/<?php echo e($other->alias, false); ?>"><?php echo $other->name; ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</section>




<?php echo $__env->make('tpl.tpl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/resources/home_service.blade.php ENDPATH**/ ?>