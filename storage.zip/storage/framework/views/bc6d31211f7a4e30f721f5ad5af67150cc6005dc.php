<section>
    <div>
        <div class="expertise">
            <div class="expertise-box">
                <h2><?php echo e($data->name, false); ?></h2>
                <p><?php echo e($data->intro, false); ?></p>
                <ul class="expertise-items">
                    <?php $__currentLoopData = $data->resourceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e($data->link, false); ?>/<?php echo e($item->alias, false); ?>">
                                <?php if($item->img): ?>
                                    <img src="/storage/<?php echo e($item->img, false); ?>" alt="img">
                                    <span><?php echo e($item->name, false); ?></span>
                                <?php else: ?>
                                    <?php echo e($item->alias, false); ?>

                                <?php endif; ?>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('tpl.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/resource_menu_icons.blade.php ENDPATH**/ ?>