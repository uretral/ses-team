<div class="detail-sticker">
    <div class="detail-sticker-block">
        <div class="detail-sticker-img">
            <img src="/img/sticker.jpg" alt="sticker"/>
        </div>
        <div class="detail-sticker-btn">
            <a href="javascript:" class="detail-sticker-btn">
                <span>заявка на стикер</span>
            </a>
        </div>

    </div>
    <div class="detail-sticker-desc">
        Все больше людей узнают наш фирменный стикер, который может оказать значительное влияние на репутацию и прибыль вашей компании. Клиенты не порекомендуют вас друзьям и коллегам и отдадут предпочтение конкурирующим компаниям, имеющим стикер SESTEAM
        <a href="/business/sticker"> Узнать больше</a>
    </div>
</div>

<?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/forms/form_siticker.blade.php ENDPATH**/ ?>