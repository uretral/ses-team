
<?php dump($backend); ?>
TEST TPL
<?php dump($data); ?>
<?php dump($data->many); ?>
<?php dump($data->bla); ?>

<?php echo \App\Models\Statics\Breadcrumbs::resource('fffffff'); ?>

<?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/test/index.blade.php ENDPATH**/ ?>