<section class="eee">
    <div class="wide banner">
        <div class="wide-box origin">
            <img src="/storage/<?php echo e($data->img, false); ?>" alt="banner"/>
			<div class="banner-slogan">
				<cite>
					<?php echo $data->cite; ?>

				</cite>
			</div>

			<?php if($data->timer): ?>
				<div id="clock">
					<div>
						Оставьте заявку в течении
						<span class="minutes"></span> :
						<span class="seconds"></span>
						и получите скидку <span>15%</span>
					</div>
				</div>
			<?php endif; ?>

		</div>
	</div>
</section>



<?php echo $__env->make('tpl.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/banner.blade.php ENDPATH**/ ?>