
<html>
<head></head>
<body>
<?php if($sender->action == 'callback'): ?>

<div style="display: table; width: 100%; text-align: center; height: 40px; background: #68A4C4; color: #fff; font-family: 'Open Sans', Arial, sans-serif; font-size: 14px; font-weight: bold;">
    <div style="display: table-cell; vertical-align: middle;">Новое сообщение от клиента <?php echo e($sender->name, false); ?>!</div>
</div>
<div>
    <div style="width: 50%; padding: 40px 25%; text-align: center;"> Страница: <?php echo $sender->page; ?></div>
</div>
<div>
    <div style="width: 50%; padding: 40px 25%; text-align: center;"><?php echo $sender->phone; ?></div>
</div>
<?php elseif($sender->action == 'aside_form'): ?>
    <div style="display: table; width: 100%; text-align: center; height: 40px; background: #68A4C4; color: #fff; font-family: 'Open Sans', Arial, sans-serif; font-size: 14px; font-weight: bold;">
        <div style="display: table-cell; vertical-align: middle;">Новое сообщение от клиента <?php echo e($sender->name, false); ?>!</div>
    </div>

    <div>
        <div style="width: 50%; padding: 40px 25%; text-align: center;"><?php echo $sender->phone; ?></div>
    </div>

    <div style="display: table; width: 100%; text-align: center; height: 40px; background: #68A4C4; color: #fff; font-family: 'Open Sans', Arial, sans-serif; font-size: 14px; font-weight: bold;">
        <div style="display: table-cell; vertical-align: middle;">E-mail для связи: <?php echo e($sender->email, false); ?></div>
    </div>
<?php elseif($sender->action == 'specialist'): ?>
    <div style="display: table; width: 100%; text-align: center; height: 40px; background: #68A4C4; color: #fff; font-family: 'Open Sans', Arial, sans-serif; font-size: 14px; font-weight: bold;">
        <div style="display: table-cell; vertical-align: middle;">Новое сообщение от клиента <?php echo e($sender->name, false); ?>!</div>
    </div>

    <div>
        <div style="width: 50%; padding: 40px 25%; text-align: center;"><?php echo $sender->phone; ?></div>
    </div>

    <div style="display: table; width: 100%; text-align: center; height: 40px; background: #68A4C4; color: #fff; font-family: 'Open Sans', Arial, sans-serif; font-size: 14px; font-weight: bold;">
        <div style="display: table-cell; vertical-align: middle;">Сфера деятельности: <?php echo e($sender->branch, false); ?></div>
    </div>
<?php endif; ?>
</body>
</html>
<?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/email/callback.blade.php ENDPATH**/ ?>