<div class="header-space"></div><?php echo \App\Models\Statics\Breadcrumbs::resource($data->name); ?><?php echo \App\Models\Statics\Share::block(); ?>

<main>
    <div>
        <div class="detail">
            <aside class="aside">
                <?php echo $__env->make('tpl.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </aside>
            <div class="detail-content">
                <h1><?php echo $data->longtitle; ?></h1>
                <?php echo \App\Models\Forms\FormSticker::block(); ?>


                <?php if(count($data->sticker)): ?>
                    <div class="detail-sticker">
                        <h2><?php echo e($data->sticker_heading, false); ?></h2>
                        <?php $__currentLoopData = $data->stickerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sticker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($sticker['name'])): ?>
                                <h3><?php echo e($sticker['name'], false); ?></h3>
                            <?php endif; ?>



                            <?php if(isset($sticker['services'])): ?>
                                <?php $__currentLoopData = $sticker['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p>
                                        <a href="<?php echo e(MENU[9]['link'], false); ?>/<?php echo e($item->alias, false); ?>"><?php echo e($item->name, false); ?></a> -

                                        <?php if(key_exists('text',$sticker)): ?>
                                            <?php echo e($sticker['text'], false); ?>

                                        <?php else: ?>
                                            <?php echo e($item->intro, false); ?>

                                        <?php endif; ?>

                                    </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <p><?php echo $data->intro; ?></p>

                <?php echo $data->desc; ?>

                <?php if($data->clients->count()): ?>
                    <h2 class="inner">Наши партнеры</h2>
                    <div class="detail-clients">

                        <?php $__currentLoopData = $data->clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <div class="detail-client">

                                <div class="detail-client-img">
                                    <div class="detail-client-portrait">
                                        <img src="/storage/<?php echo e($partner->img, false); ?>" alt=""/>
                                    </div>
                                </div>

                                <b><?php echo e($partner->name, false); ?></b>
                                <?php echo $partner->intro; ?>

                                <a href="<?php echo e(MENU['12']['link'], false); ?>/<?php echo e($partner->alias, false); ?>">Читать далее</a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php if($data->art->count()): ?>
                    <h2 class="inner">Статьи</h2>
                    <div class="detail-articles">
                        <?php $__currentLoopData = $data->art; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="detail-article">
                                <a href="<?php echo e(MENU[15]['link'], false); ?>/<?php echo e($article->alias, false); ?>" class="detail-article"><?php echo e($article->name, false); ?></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <?php if(isset($data->price)): ?>
                    <div class="detail-contrast">
                        <div class="detail-contrast-header">
                            <p>Прайс-лист</p>
                        </div>
                        <div class="detail-contrast-body">
                            <?php echo $data->price; ?>

                        </div>
                        <div class="detail-contrast-footer"></div>
                    </div>
                <?php endif; ?>

                <?php if(isset($data->warranty)): ?>
                    <div class="detail-contrast">
                        <div class="detail-contrast-header">
                            <p>Гарантия</p>
                        </div>
                        <div class="detail-contrast-body">
                            <?php echo $data->warranty; ?>

                        </div>
                        <div class="detail-contrast-footer"></div>
                    </div>
                <?php endif; ?>

                <?php if(isset($data->aim_heading)): ?>
                    <div class="detail-aim">
                        <div class="detail-aim-img">
                            <img src="/storage/<?php echo e($data->aim_img, false); ?>" alt="img"/>
                        </div>
                        <div class="detail-aim-text">
                            <h2><?php echo $data->aim_heading; ?></h2>
                            <?php echo $data->aim_text; ?>

                        </div>
                    </div>
                <?php endif; ?>
                <?php echo \App\Models\Forms\FormFeedback::block(); ?>

            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('tpl.tpl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/resources/branch.blade.php ENDPATH**/ ?>