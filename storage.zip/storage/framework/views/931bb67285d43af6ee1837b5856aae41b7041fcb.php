<section>
    <div class="double top">
        <div class="double-header">
            <h2><?php echo e($data->name, false); ?></h2>
            <p>
                <?php echo e($data->introtext, false); ?>

            </p>
        </div>

        <div class="double-items ">
            <div class="double-item bottom">
                <div class="accordion">

                    <?php $left = 0   ?>
                    <?php $__currentLoopData = $data->accordion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(key_exists('position',$item)): ?>
                            <input type="radio" id="<?php echo e($data->id, false); ?>-accordion-<?php echo e($k, false); ?>" name="<?php echo e($data->id, false); ?>-accordion-left" <?php if($left == 0 ): ?> checked <?php endif; ?>>
                            <label for="<?php echo e($data->id, false); ?>-accordion-<?php echo e($k, false); ?>"><?php echo e($item['name'], false); ?></label>
                            <div>
                                <p><?php echo e($item['text'], false); ?></p>
                                <?php if(key_exists('link',$item)): ?>
                                    <a href="<?php echo e($item['link'], false); ?>">Узнать больше &gt;</a>
                                <?php endif; ?>
                            </div>
                            <?php $left++ ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php  unset($left)  ?>
                </div>
            </div>
            <div class="double-item bottom">
                <div class="accordion">
                    <?php $right = 0   ?>
                    <?php $__currentLoopData = $data->accordion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!key_exists('position',$item)): ?>
                            <input type="radio" id="<?php echo e($data->id, false); ?>-accordion-<?php echo e($k, false); ?>" name="<?php echo e($data->id, false); ?>-accordion-right" <?php if($right == 0 ): ?> checked <?php endif; ?>>
                            <label for="<?php echo e($data->id, false); ?>-accordion-<?php echo e($k, false); ?>"><?php echo e($item['name'], false); ?></label>
                            <div>
                                <p><?php echo e($item['text'], false); ?></p>
                                <?php if(key_exists('link',$item)): ?>
                                    <a href="<?php echo e($item['link'], false); ?>">Узнать больше &gt;</a>
                                <?php endif; ?>
                            </div>
                            <?php $right++ ?>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php  unset($right)  ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('tpl.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/accordions.blade.php ENDPATH**/ ?>