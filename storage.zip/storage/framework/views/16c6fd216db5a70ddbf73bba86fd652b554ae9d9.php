<div class="header-space"></div>
<?php echo \App\Models\Statics\Breadcrumbs::resource($data->name); ?>

<?php echo \App\Models\Statics\Share::block(); ?>


<main>
    <div>
        <div class="detail">
            <aside class="aside">
                <?php echo $__env->make('tpl.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </aside>
            <div class="detail-content">
                <h1><?php echo $data->name; ?></h1>

                <h3><?php echo $data->intro; ?></h3>

                <?php echo $data->desc; ?>


                <?php $__currentLoopData = $data->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="detail-contrast">
                        <div class="detail-contrast-header">
                            <p><?php echo $price->name; ?></p>
                        </div>
                        <div class="detail-contrast-body">
                            <?php echo $price->price; ?>

                        </div>
                        <div class="detail-contrast-footer"></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <?php if(isset($data->branchesArray)): ?>
                    <h2 class="inner">Сферы бизнеса</h2>
                    <ul class="detail-branches">
                        <?php $__currentLoopData = $data->branchesArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="detail-branches-links">
                                <a href="<?php echo e(MENU[8]['link'], false); ?>/<?php echo e($branch->alias, false); ?>">
                                    <img src="/storage/<?php echo e($branch->img, false); ?>" alt="img">
                                    <span><?php echo $branch->name; ?></span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>












                <?php endif; ?>

 



                <?php if(isset($data->warranty)): ?>
                    <div class="detail-contrast">
                        <div class="detail-contrast-header">
                            <p>Гарантия</p>
                        </div>
                        <div class="detail-contrast-body">
                            <?php echo $data->warranty; ?>

                        </div>
                        <div class="detail-contrast-footer"></div>
                    </div>
                <?php endif; ?>

                <?php if(isset($data->aim_heading)): ?>
                    <div class="detail-aim">
                        <div class="detail-aim-img">
                            <img src="/storage/<?php echo e($data->aim_img, false); ?>" alt="img"/>
                        </div>
                        <div class="detail-aim-text">
                            <h2><?php echo $data->aim_heading; ?></h2>
                            <?php echo $data->aim_text; ?>

                        </div>
                    </div>
                <?php endif; ?>

                <?php echo $__env->make('forms.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('tpl.tpl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/resources/business_service.blade.php ENDPATH**/ ?>