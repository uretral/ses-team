<section>
    <div class="triple both">
        <div class="triple-header">
            <?php if(isset($data->sign)): ?>
                <div class="count">
                    <div class="count-info">
                        <span><em><?php echo e($data->sign, false); ?></em></span>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(isset($data->title)): ?>
                    <h2 class="tall">
                        <?php echo $data->title; ?>

                    </h2>
            <?php endif; ?>
        </div>
        <div class="triple-items">
            <div class="triple-item border">
                <?php if(isset($data->col_1_name)): ?>
                    <h3><?php echo $data->col_1_name; ?></h3>
                <?php endif; ?>
                <?php if(isset($data->col_1_text)): ?>
                    <p><?php echo $data->col_1_text; ?></p>
                <?php endif; ?>
                <?php if(isset($data->col_1_link)): ?>
                        <a href="<?php echo $data->col_1_link; ?>">Больше информации</a>
                <?php endif; ?>
            </div>
            <div class="triple-item border">
                <?php if(isset($data->col_2_name)): ?>
                    <h3><?php echo $data->col_2_name; ?></h3>
                <?php endif; ?>
                <?php if(isset($data->col_2_text)): ?>
                    <p><?php echo $data->col_2_text; ?></p>
                <?php endif; ?>
                <?php if(isset($data->col_2_link)): ?>
                    <a href="<?php echo $data->col_2_link; ?>">Больше информации</a>
                <?php endif; ?>
            </div>
            <div class="triple-item border">
                <?php if(isset($data->col_3_name)): ?>
                    <h3><?php echo $data->col_3_name; ?></h3>
                <?php endif; ?>
                <?php if(isset($data->col_3_text)): ?>
                    <p><?php echo $data->col_3_text; ?></p>
                <?php endif; ?>
                <?php if(isset($data->col_3_link)): ?>
                    <a href="<?php echo $data->col_3_link; ?>">Больше информации</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('tpl.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/triple_text.blade.php ENDPATH**/ ?>