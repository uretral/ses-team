<section>
	<div class="breadcrumbs">
		<div class="breadcrumbs-box">
			<a href="/">Главная</a>
			<em>»</em>
			<?php if(isset($data)): ?>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($link != 'last'): ?>
						<a href="<?php echo e($link, false); ?>"><?php echo e($name, false); ?></a>
						<em>»</em>
					<?php else: ?>
						<span><?php echo e($name, false); ?></span>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
	</div>
</section>




<?php echo $__env->make('tpl.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/breadcrumbs_full.blade.php ENDPATH**/ ?>