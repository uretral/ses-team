
<ul class="main_nav">

    <li class="root">
        <a class="<?php echo e(MENU[8]['active'], false); ?>" href="javascript:"><span>Сферы бизнеса</span></a>
        <ul class="sub-menu">

            <li>
                <ul class="sub-menu-level">
                    <?php $__currentLoopData = MENU[10]['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branchKey => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(($branchKey % 2) == 0): ?>
                            <li>
                                <a class="<?php echo e($branch['active'], false); ?>" href="<?php echo e($branch['link'], false); ?>"><?php echo e($branch['name'], false); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li>
                <ul class="sub-menu-level">
                    <?php $__currentLoopData = MENU[10]['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branchKey => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(($branchKey % 2) != 0): ?>
                            <li>
                                <a class="<?php echo e($branch['active'], false); ?>" href="<?php echo e($branch['link'], false); ?>"><?php echo e($branch['name'], false); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>

        </ul>
    </li>

    <li class="root">
        <a class="<?php echo e(MENU[9]['active'], false); ?>" href="javascript:"><span>Наши услуги</span></a>
        <ul class="sub-menu">
            <?php
                $arPos = [];
                foreach (MENU[21]['child'] as $position){
                $arPos[$position['menu_position']][] = $position;
                }
                ksort($arPos)
            ?>

            <?php $__currentLoopData = $arPos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posKey => $servicesCategories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <ul class="sub-menu-level">

                <?php $__currentLoopData = $servicesCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $arChild = [];
                                    foreach (MENU[11]['child'] as $child)
                                    if($child['parent'] == $category['id']){
                                    $arChild[] = $child;
                                    }
                                ?>

                            <h4><?php echo e($category['name'], false); ?></h4>
                                <li class="underlined">
                            <li class="sub-menu-double">
                                <ul class="sub-menu-vertical">

                                    <?php $__currentLoopData = $arChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($service['parent'] == $category['id']): ?>
                                            <li>
                                                <a class="<?php echo e($service['active'], false); ?>" href="<?php echo e($service['link'], false); ?>">
                                                    <?php if(isset($service['name_short'])): ?>
                                                        <?php echo e($service['name_short'], false); ?>

                                                    <?php endif; ?>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    </li>


    <li class="root">
        <a class="<?php echo e(MENU[22]['active'], false); ?>" href="<?php echo e(MENU[22]['link'], false); ?>"><span><?php echo e(MENU[22]['name'], false); ?></span></a>

        <ul class="sub-menu">
            <li>
                <ul class="sub-menu-level">
                    <h4>Стикер SESTEAM</h4>
                    <?php $__currentLoopData = MENU; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sticker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($sticker['parent']  == 22): ?>
                            <li>
                                <a class="<?php echo e($sticker['active'], false); ?>" href="<?php echo e($sticker['link'], false); ?>"><?php echo e($sticker['name'], false); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
        </ul>
    </li>


    <li>
        <a class="<?php echo e(MENU[12]['active'], false); ?>" href="<?php echo e(MENU[12]['link'], false); ?>"><span><?php echo e(MENU[12]['name'], false); ?></span></a>
    </li>



    <li>
        <a class="<?php echo e(MENU[7]['active'], false); ?>" href="<?php echo e(MENU[7]['link'], false); ?>"><span><?php echo e(MENU[7]['name'], false); ?></span></a>
    </li>
</ul>
<?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/tpl/menu_business.blade.php ENDPATH**/ ?>