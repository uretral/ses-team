<section>
    <div class="share">
        <div class="share-col">
            <div class="share-cell">
                <span>Поделиться:</span>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a rel="nofollow" target="_blank" title="<?php echo e($i->name, false); ?>" href="<?php echo e($i->link, false); ?>:">
                        <img src="/storage/<?php echo e($i->img, false); ?>" alt="<?php echo e($i->name, false); ?>"/>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/share.blade.php ENDPATH**/ ?>