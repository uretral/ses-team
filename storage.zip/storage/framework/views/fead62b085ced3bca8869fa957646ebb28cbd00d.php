<div class="header-space"></div><?php echo \App\Models\Statics\Breadcrumbs::resource($data->name); ?><?php echo \App\Models\Statics\Share::block(); ?>

<main>
    <div>
        <div class="detail">
            <aside class="aside">
                <?php echo $__env->make('tpl.aside_sticker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </aside>
            <div class="detail-content">
                <h1><?php echo $data->intro; ?></h1>

                <?php echo $data->content; ?>


                <?php echo \App\Models\Forms\FormFeedback::block(); ?>

            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('tpl.tpl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/sticker.blade.php ENDPATH**/ ?>