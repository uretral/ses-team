<section>
    <div class="wide collection">
        <h1>Поиск</h1>
        <?php if($data): ?>
            <p>Результаты поиска по запросу <b><?php echo e(request()->get('q'), false); ?></b></p>
        <?php else: ?>
            <p>Результаты поиска по запросу <b><?php echo e(request()->get('q'), false); ?></b> не найдены</p>
        <?php endif; ?>

        <div class="collection-search-container">

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <h2><?php echo e($section['parent']->name, false); ?>

                    
                </h2>
                <div class="collection-search">
                    <?php $__currentLoopData = $section['collection']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="collection-search-item">
                            <a href="<?php echo e(str_replace('{alias}',$item->alias,$section['menu']->link), false); ?>"><?php echo e($item->name, false); ?></a>
                            <p>
                                <?php echo $item->intro; ?>

                            </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</section>
<?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/search.blade.php ENDPATH**/ ?>