<section>
    <div class="wide">
        <div class="wide-content">
            <h1><?php echo e($data->name, false); ?></h1>

            <?php echo $data->intro; ?>


            <?php $__currentLoopData = $data->resource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$branch->children->isEmpty()): ?>
                    <div class="browse">
                        <h2><?php echo e($branch->name, false); ?></h2>
                        <div class="browse-items carousel">
                            <?php $__currentLoopData = $branch->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="browse-item">
                                    <div class="browse-item-img">
                                        <div class="browse-item-portrait">
                                            <?php if($client->img): ?>
                                                <img src="/storage/<?php echo e($client->img, false); ?>" alt="img"/>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <b><?php echo e($client->name, false); ?></b>
                                    <p>
                                        <?php echo e(Str::limit($client->intro, 100, '...'), false); ?>

                                    </p>

                                    <a href="<?php echo e(MENU[$data->parent]['link'], false); ?>/<?php echo e($client->alias, false); ?>">Узнать больше ...</a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

</section>





<?php echo $__env->make('tpl.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/carousel_resource.blade.php ENDPATH**/ ?>