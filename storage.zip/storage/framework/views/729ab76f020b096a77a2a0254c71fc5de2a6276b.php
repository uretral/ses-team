<section>
	<div>
		<div class="communication">
			<div class="communication-callback">
				<span>Найдите ваш регион</span>
				<select class="simple inter">
					<?php $__currentLoopData = \App\Admin\Controllers\SiteController::regions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option <?php if(request()->root() == $region->url): ?> selected <?php endif; ?> value="<?php echo e($region->url, false); ?>"><?php echo e($region['region'], false); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>

				<span>Или звоните: <em><?php echo e(REGION['phone'], false); ?></em></span>
			</div>
			<div class="communication-feedback">
				<mark>
					<span>Сергей Новиков г. Москва</span>
					<cite>
						Настоящий ОПЫТ.  ...ЭТО ДЕЙСТВИТЕЛЬНО  ТО, ЧТО ВЫ ПОКАЗЫВАЕТЕ В своих делах. <em>... потрясающий опыт.</em>
					</cite>

				</mark>

				<a class="btn" href="javascript:"><span>GET STARTED</span></a>
			</div>
			<div class="hr"></div>
		</div>
	</div>
</section>

<?php echo $__env->make('tpl.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/region_with_cite.blade.php ENDPATH**/ ?>