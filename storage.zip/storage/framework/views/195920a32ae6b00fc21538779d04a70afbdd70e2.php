<section>
    <div class="schedule">
        <div class="schedule-header">
            <p>Свяжитесь с нашим специалистом: <a href="tel:<?php echo e(REGION['phone_href'], false); ?>"><?php echo e(REGION['phone'], false); ?></a></p>
        </div>
        <div class="schedule-body">
            <legend>Бесплатная консультация:</legend>
            <form class="schedule-form" action="javascript:" id="specialist">
                <input type="hidden" name="action" value="specialist"/>
                <label for="schedule-branch">
                    <select id="schedule-branch" class="simple" name="branch">
                        <option value="Select Industry">Сфера бизнеса</option>
                        <?php if(isset($data)): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->name, false); ?>"><?php echo e($item->name, false); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </label>
                <input type="text" placeholder="Имя" name="name"/>
                <input type="tel" placeholder="Телефон" name="phone"/>
                <button class="black" type="submit"><span>Отправить</span></button>
            </form>

        </div>
        <div class="schedule-footer"></div>
    </div>
</section>

<?php echo $__env->make('tpl.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/form_branches.blade.php ENDPATH**/ ?>