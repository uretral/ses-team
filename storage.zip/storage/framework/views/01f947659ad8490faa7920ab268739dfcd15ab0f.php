<div class="header-space"></div>
<?php echo \App\Models\Statics\Breadcrumbs::resource($data->name); ?>

<?php echo \App\Models\Statics\Share::block(); ?>


<main>
    <div>
        <div class="detail">
            <aside class="aside">
                <?php echo $__env->make('tpl.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </aside>
            <div class="detail-content">
                <h1><?php echo $data->name; ?></h1>
                <p><?php echo $data->intro; ?></p>
                <?php echo $data->desc; ?>

                
                <?php echo $__env->make('forms.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>
</main>

<?php echo $__env->make('tpl.tpl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/resources/article.blade.php ENDPATH**/ ?>