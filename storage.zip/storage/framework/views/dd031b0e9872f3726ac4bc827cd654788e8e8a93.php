<div class="header-space"></div><?php echo \App\Models\Statics\Breadcrumbs::resource($data->name); ?><?php echo \App\Models\Statics\Share::block(); ?>


<main>
    <div>
        <div class="detail">
            <aside class="aside">
                <?php echo $__env->make('tpl.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </aside>
            <div class="detail-content">
                <h1><?php echo $data->name; ?></h1>

                <div class="listing">
                    <?php $__currentLoopData = $data->resourceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="listing-item">
                            <div class="listing-item-img">
                                <div class="browse-item-portrait">
                                    <?php if($client->img): ?>
                                        <img src="/storage/<?php echo e($client->img, false); ?>" alt="img"/>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <b><?php echo e($client->name, false); ?></b>
                            <p>
                                <?php echo e(Str::limit($client->intro, 100, '...'), false); ?>

                            </p>

                            <a href="<?php echo e(MENU[$data->parent]['link'], false); ?>/<?php echo e($client->alias, false); ?>">Узнать больше ...</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php echo \App\Models\Forms\FormFeedback::block(); ?>

            </div>
        </div>
    </div>
</main>


<?php echo $__env->make('tpl.tpl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/listing.blade.php ENDPATH**/ ?>