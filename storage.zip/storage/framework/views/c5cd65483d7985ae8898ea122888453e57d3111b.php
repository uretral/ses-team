<section>
	<div class="zip">
		<div class="zip-box gray">
			<span>Найдите ваш регион</span>


			<select class="simple wider">
				<?php $__currentLoopData = \App\Admin\Controllers\SiteController::regions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option <?php if(request()->root() == $region->url): ?> selected <?php endif; ?> value="<?php echo e($region->url, false); ?>"><?php echo e($region['region'], false); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>

			<span>Или позвоните: <em><?php echo e(REGION['phone'], false); ?></em></span>
		</div>
	</div>
</section>

<?php echo $__env->make('tpl.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/region_search_with_phone.blade.php ENDPATH**/ ?>