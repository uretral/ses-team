<section>
	<div>
		<div class="communication">
			<div class="communication-callback">
				<span>Найдите ваш регион</span>
				<div class="communication-callback_col">
					<label>
						<input class="region-search" type="text" placeholder="Ваш регион..."/>
						<button class="region-sbt"><b>GO</b></button>
					</label>
					<ul class="regions-list"></ul>
				</div>
				<span>OR CALL: <em>844-514-3974</em></span>
			</div>
			<div class="communication-feedback">
				<mark>
					<span>Сергей Новиков г. Москва</span>
					<cite>
						Настоящий ОПЫТ.  ...ЭТО ДЕЙСТВИТЕЛЬНО  ТО, ЧТО ВЫ ПОКАЗЫВАЕТЕ В своих делах. <em>... потрясающий опыт.</em>
					</cite>

				</mark>

				<a class="btn" href="javascript:"><span>GET STARTED</span></a>
			</div>
			<div class="hr"></div>
		</div>
	</div>
</section>

<?php dump($data); ?>




<?php echo $__env->make('tpl.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/blocks/cite.blade.php ENDPATH**/ ?>