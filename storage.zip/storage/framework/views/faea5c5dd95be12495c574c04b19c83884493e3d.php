<div class="form-group <?php echo !$errors->has($errorKey) ?: 'has-error'; ?>">

    <label for="<?php echo e($id, false); ?>" class="col-sm-2 control-label"><?php echo e($label, false); ?></label>

    <div class="col-sm-8">


        <div class="dd dd-wide">
            <ol class="dd-list">
                <?php if(isset($value)): ?>
                    <?php $__currentLoopData = json_decode($value); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li
                            id="<?php echo e($val->nr, false); ?>"
                            class="dd-item dd3-item"
                            data-name="<?php echo e($val->name, false); ?>"
                            data-url="<?php echo e($val->url, false); ?>"
                            data-nr="<?php echo e($val->nr, false); ?>"
                            data-controller="<?php echo e($val->controller, false); ?>"
                            data-model="<?php echo e($val->model, false); ?>"
                            data-id="<?php echo e($val->id, false); ?>"
                            data-title="<?php echo e($val->title, false); ?>"
                            data-static="<?php echo e($val->static, false); ?>"

                        >
                            <div class="dd-handle dd3-handle"></div>
                            <div class="dd3-content">
                                <?php echo e($val->name, false); ?> (<?php echo e($val->title, false); ?>)
                                <a

                                    href="javascript:"
                                    <?php if($val->static): ?>
                                    class="static_delete danger"
                                    rel="/admin/static/<?php echo e($val->url, false); ?>?parent=<?php echo e($res, false); ?>&nr=<?php echo e($val->nr, false); ?>"
                                    <?php else: ?>
                                    class="block_delete danger"
                                    rel="/admin/block/<?php echo e($val->url, false); ?>/<?php echo e($val->id, false); ?>"
                                    <?php endif; ?>
                                    data-code="<?php echo e($val->nr, false); ?>"
                                    title="Удалить"> Удалить</a>
                                <a
                                    class="block_view"
                                    <?php if($val->static): ?>
                                    rel="/blocks/<?php echo e($val->url, false); ?>/<?php echo e($res, false); ?>/<?php echo e($val->static, false); ?>/1"
                                    <?php else: ?>
                                    rel="/blocks/<?php echo e($val->url, false); ?>/<?php echo e($val->id, false); ?>/<?php echo e($val->static, false); ?>/1"
                                    <?php endif; ?>

                                    data-code="<?php echo e($val->nr, false); ?>"
                                    href="javascript:"
                                    title="Посмотреть"> Просмотр </a>
                                <?php if(!$val->static): ?>
                                <a
                                    class="block_edit"
                                    data-name="<?php echo e($val->name, false); ?>"
                                    rel="/admin/block/<?php echo e($val->url, false); ?>/<?php echo e($val->id, false); ?>/edit?parent=<?php echo e($res, false); ?>&nr=<?php echo e($val->nr, false); ?>"
                                    href="javascript:"
                                    title="Редактировать"> Редактировать </a>
                                <a target="_blank" href="/blocks/<?php echo e($val->url, false); ?>/<?php echo e($val->id, false); ?>/1"> >> </a>
                                <?php endif; ?>


                            </div>
                            <div class="dd3-view" id="nest_<?php echo e($val->nr, false); ?>"></div>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </ol>
        </div>
        <?php echo $__env->make('admin::form.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="hidden" id="blocks_json" name="<?php echo e($name, false); ?>" value="<?php echo e($value, false); ?>"/>
        <?php echo $__env->make('admin::form.help-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <data id="block_target" rel="<?php echo e($res, false); ?>"></data>


        <span class="grid-expand" data-toggle="modal" data-target="#grid-modal-22">
   <a href="javascript:void(0)"></a>
</span>

        <div class="modal fade" id="grid-modal-22" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document" style="width: 90%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title"></h4>
                    </div>
                    <div class="modal-body">
                        {$html}
                    </div>
                </div>
            </div>
        </div>

    </div>



</div>
<?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/vendor/encore/laravel-admin/src/../resources/views/form/sortable.blade.php ENDPATH**/ ?>