<div class="header-space"></div>
<?php echo \App\Models\Statics\Breadcrumbs::resource($data->name); ?>

<?php echo \App\Models\Statics\Share::block(); ?>


<main>
    <div>
        <div class="detail">
            <aside class="aside">
                <?php echo $__env->make('tpl.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </aside>
            <div class="detail-content">
                <h1><?php echo $data->name; ?></h1>
                <p><?php echo $data->intro; ?></p>

                <img src="/storage/<?php echo e($data->img, false); ?>" alt=""/>

                <?php echo $data->desc; ?>

                <?php if(isset($data->partners)): ?>
                    <h2 class="inner">Наши партнеры</h2>
                    <div class="detail-clients">
                        <?php $__currentLoopData = $data->partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="detail-client">

                                <strong><?php echo e($partner->name, false); ?></strong>

                                <img src="/upload/<?php echo e($partner->img, false); ?>" alt=""/>
                                <?php echo $partner->intro; ?>

                                <a href="<?php echo e($partner->link, false); ?>">Читать далее</a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <?php if(isset($articles)): ?>
                    <h2 class="inner">Статьи</h2>
                    <div class="detail-articles">
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="detail-article">
                                <a href="<?php echo e($article->link, false); ?>" class="detail-article"><?php echo e($article->name, false); ?></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <?php echo $__env->make('forms.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>
</main>



<?php echo $__env->make('tpl.tpl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/resources/client.blade.php ENDPATH**/ ?>