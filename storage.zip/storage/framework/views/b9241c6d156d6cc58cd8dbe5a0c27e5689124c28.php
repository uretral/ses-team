<div class="aside-region">
    <h3>Представители в регионах</h3>
    <p>Выберите ваш регион:</p>
    <select class="simple">
        <?php $__currentLoopData = \App\Admin\Controllers\SiteController::regions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if(request()->root() == $region->url): ?> selected <?php endif; ?> value="<?php echo e($region->url, false); ?>"><?php echo e($region['region'], false); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
     <br/>
     <br/>
     <br/>
    <div rel="region"></div>
</div>
<div class="aside-call">
    <h3>Беспокоят насекомые?</h3>
    <p class="tel">
        Позвоните нам: <span><?php echo e(REGION['phone'], false); ?></span>
    </p>
    <p>
        Или отправьте нам заявку, мы перезвоним Вам в течении 5ти минут:
    </p>

    <form action="javascript:" id="aside_form">
        <input type="hidden" name="action" value="aside_form"/>
        <input type="text" name="name" placeholder="ваше имя"/>
        <input type="email" name="email" placeholder="ваше email"/>
        <input type="tel" name="phone" placeholder="ваше телефон"/>
        <button class="sbt"><span>Отправить</span></button>
        <mark>
            Нажимая на кнопку "Отправить", я даю
            <a href="/agreement.html">согласие на обработку персональных данных</a>
            . Информация на сайте не является публичной
            <a href="/oferta.html">офертой</a>
        </mark>
    </form>
</div>

<?php if($data->aside_cite_text && $data->aside_cite_switcher): ?>
    <div class="aside-info">
        <mark>
<?php echo $data->aside_cite_text; ?>

        </mark>
    </div>
<?php elseif($data->aside_cite_switcher): ?>
    <div class="aside-banner">
        <?php if($data->aside_cite_link): ?>
            <a href="<?php echo e($data->aside_cite_link, false); ?>">
                <img src="/storage/<?php echo e($data->aside_cite_img, false); ?>" alt="img"/>
            </a>
            <?php else: ?>
            <img src="/storage/<?php echo e($data->aside_cite_img, false); ?>" alt="img"/>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php if($data->aside_advert_text && $data->aside_advert_switcher): ?>
    <div class="aside-info">
        <mark>
            <?php echo $data->aside_advert_text; ?>

        </mark>
    </div>
<?php elseif($data->aside_advert_switcher): ?>
    <div class="aside-banner">
        <?php if($data->aside_advert_link): ?>
            <a href="<?php echo e($data->aside_advert_link, false); ?>">
                <img src="/storage/<?php echo e($data->aside_advert_img, false); ?>" alt="img"/>
            </a>
        <?php else: ?>
            <img src="/storage/<?php echo e($data->aside_advert_img, false); ?>" alt="img"/>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/tpl/aside.blade.php ENDPATH**/ ?>