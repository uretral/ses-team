<div class="header-space"></div>
<?php echo \App\Models\Statics\Breadcrumbs::resource($data->name); ?>

<?php echo \App\Models\Statics\Share::block(); ?>

<main>
    <div>
        <div class="wide">
            <div class="wide-content">
                <h1><?php echo e($data->name, false); ?></h1>
                <?php echo $data->introtext; ?>

                    <?php $__currentLoopData = $data->tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="table">
                        <div class="table-header">
                            <div class="table-link">
                                <a href="<?php echo e($table->link, false); ?>"><?php echo e($table->name, false); ?></a>
                            </div>
                        </div>
                        <div class="table-col imaged" style="background-image: url('/storage/<?php echo e($table->img, false); ?>')">

                        </div>
                        <div class="table-col">
                            <div class="table-txt"><?php echo $table->col_1; ?></div>
                        </div>
                        <div class="table-col">
                            <div class="table-txt"><?php echo $table->col_2; ?></div>
                        </div>
                        <div class="table-col">
                            <div class="table-txt"><?php echo $table->col_3; ?></div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</main>
<?php echo $__env->make('blocks.region_search_with_phone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('tpl.tpl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/resources/table_content.blade.php ENDPATH**/ ?>