<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link rel="shortcut icon" href="favicon.ico" />
    <link href="<?php echo e(asset('less/style.css'), false); ?>" rel="stylesheet">
    <title></title>
</head>
<body>

<header>
    <div>
        <div class="header">
            <a class="header-call-btn" href="javascript:"></a>
            <div class="header-logo">
                <a href="<?php echo e(MENU[1]['link'], false); ?>">
                    <img src="<?php echo e(asset('img/logo.jpg'), false); ?>" alt="logo" style="    width: 70%;    margin: 0 auto;    display: block;"/>
                </a>
            </div>
            <input type="checkbox" id="topMenuSwitcher"/>
            <label for="topMenuSwitcher">
                <span></span>
                <span></span>
                <span></span>
            </label>
            <div class="header-nav">
                <div class="header-nav-info">
                    <a href="tel:<?php echo e(REGION['phone_href'], false); ?>"><span>Тел: <?php echo e(REGION['phone'], false); ?></span></a>
                    <input type="checkbox" id="regionsSwitcher"/>
                    <label for="regionsSwitcher"><span>Регионы</span>
                        <div class="regions-top">
                            <div rel="region"></div>
                            <select class="simple wider">
                                <?php $__currentLoopData = \App\Admin\Controllers\SiteController::regions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if(request()->root() == $region->url): ?> selected <?php endif; ?> value="<?php echo e($region->url, false); ?>"><?php echo e($region['region'], false); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </label>
                    <input  type="checkbox" id="mobileSearchSwitcher"/>
                    <label for="mobileSearchSwitcher"><span>Поиск</span>

                        <form class="mobile-search-top" action="<?php echo e(MENU[6]['link'], false); ?>" method="get">
                            <label>
                                <input type="search" name="q" value=""/>
                            </label>
                            <button type="submit"><em>Поиск</em></button>
                        </form>
                    </label>

                    <a href="javascript:"><span>поддержка</span></a>
                </div>
                <div class="header-nav-main">
                    <div class="header-nav-menu">
                        <div class="header-nav-menu_top">
                            <?php if(strpos(url()->current(),'business')): ?>
                                <a href="<?php echo e(MENU[1]['link'], false); ?>">Для дома</a>
                                <a class="<?php echo e(MENU[4]['active'], false); ?>" href="<?php echo e(MENU[4]['link'], false); ?>">Для бизнеса</a>
                            <?php else: ?>
                                <a class="<?php echo e(MENU[1]['active'], false); ?>" href="<?php echo e(MENU[1]['link'], false); ?>">Для дома</a>
                                <a href="<?php echo e(MENU[4]['link'], false); ?>">Для бизнеса</a>
                            <?php endif; ?>
                        </div>
                        <div class="header-nav-menu_main">
                            <input type="checkbox" id="searchSwitcher"/>
                            <label for="searchSwitcher"></label>
                            <form class="search-top" action="<?php echo e(MENU[6]['link'], false); ?>">
                                <label>
                                    <input type="search" name="q" value=""/>
                                </label>
                                <button type="submit"><em>Поиск</em></button>
                            </form>
                            <?php if(strpos(url()->current(),'business')): ?>
                                <?php echo $__env->make('tpl.menu_business', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                                <?php echo $__env->make('tpl.menu_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="header-nav-callback">
                        <a href="javascript:" class="red-callback" rel="modal" data-action="callback" >Оставить<span>Заявку</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>




<?php echo $__env->yieldContent('content'); ?>


<footer>

    <div class="footer">
        <div class="footer-box">
            <div class="footer-links">
                <div class="footer-links_media">
                    <h5>Почему SESTEAM</h5>
                    <ul>
                        <li>
                            <a href="<?php echo e(MENU[26]['link'], false); ?>"><span><?php echo e(MENU[26]['name'], false); ?></span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(MENU[27]['link'], false); ?>"><span><?php echo e(MENU[27]['name'], false); ?></span></a>
                        </li>

                    </ul>
                </div>

                <div class="footer-links_socials">
                    <h5>Мы в соц.сетях</h5>
                    <ul>
                        <li>
                            <a rel="nofollow" href="javascript:" class="facebook" target="_blank">facebook</a>
                        </li>
                        <li>
                            <a rel="nofollow" href="javascript:" class="youtube" target="_blank">youtube</a>
                        </li>
                        <li>
                            <a rel="nofollow" href="javascript:" class="twitter" target="_blank">twitter</a>
                        </li>
                        <li>
                            <a rel="nofollow" href="javascript:" class="pinterest" target="_blank">pinterest</a>
                        </li>
                        <li>
                            <a rel="nofollow" href="javascript:" class="email" target="_blank">email</a>
                        </li>
                    </ul>
                </div>
                <div class="footer-links_other">
                    <h5>Поддержка</h5>
                    <ul>
                        <li>
                            <a href="<?php echo e(MENU[28]['link'], false); ?>"><span><?php echo e(MENU[28]['name'], false); ?></span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(MENU[22]['link'], false); ?>"><span><?php echo e(MENU[22]['name'], false); ?></span></a>
                        </li>

                    </ul>
                </div>
            </div>
            <div class="footer-copyrights">
                <p>© 2019 Ses Team</p>
            </div>
            <div class="footer-terms">
                <a href="javascript:">условия пользования</a>
                |
                <a href="javascript:">Политика конфедициальности</a>
                |
                <a href="javascript:">карта сайта
                </a>
            </div>
        </div>
    </div>
    <section class="modal">
    	<div>
    		<div class="modal-wrapper">
                <div class="modal-content">
                    <a href="javascript:;" class="modal-close"></a>
                    <div class="callback-form form">
                        <form action="javascript:" id="callback">
                            <input type="hidden" name="action" value="callback"/>
                            <input type="hidden" name="discount" value="без скидки">
                            <label><input type="hidden" name="page" value="<?php echo e(request()->fullUrl(), false); ?>"/></label>
                            <label><input type="text" name="name" placeholder="Ваше имя"/></label>
                            <label><input type="tel" name="phone" placeholder="Ваш телефон"/></label>
                            <label><input type="submit" value="Отправить"/></label>
                        </form>
                    </div>
                </div>
    		</div>
    	</div>
    </section>
</footer>

<script src="<?php echo e(asset('js/jq.js'), false); ?>"></script>
<script src="<?php echo e(asset('js/owl.carousel.js'), false); ?>"></script>
<script src="<?php echo e(asset('js/jquery.inputmask.bundle.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('js/script.js'), false); ?>"></script>
</body>
</html>
<?php /**PATH /home/c/cv05345/st.cv05345.tmweb.ru/resources/views/tpl/tpl.blade.php ENDPATH**/ ?>