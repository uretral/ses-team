
@dump($backend)
TEST TPL
@dump($data)
@dump($data->many)
@dump($data->bla)

{!! \App\Models\Statics\Breadcrumbs::resource('fffffff') !!}
