@extends('tpl.tpl')
{{--@dump($data)--}}
{{--@dump(MENU)--}}

{!! $data !!}
