<footer>

    <div class="footer">
        <div class="footer-box">
            <div class="footer-links">
                <div class="footer-links_media">
                    <h5>Why Orkin</h5>
                    <ul>
                        <li>
                            <a href="javascript:">Careers</a>
                        </li>
                        <li>
                            <a href="javascript:">Media/News Room</a>
                        </li>
                        <li>
                            <a href="javascript:">Franchise Opportunities</a>
                        </li>
                        <li>
                            <a href="javascript:">Selling Your Business</a>
                        </li>
                    </ul>
                </div>

                <div class="footer-links_socials">
                    <h5>Connect With US</h5>
                    <ul>
                        <li>
                            <a rel="nofollow" href="javascript:" class="facebook" target="_blank">facebook</a>
                        </li>
                        <li>
                            <a rel="nofollow" href="javascript:" class="youtube" target="_blank">youtube</a>
                        </li>
                        <li>
                            <a rel="nofollow" href="javascript:" class="twitter" target="_blank">twitter</a>
                        </li>
                        <li>
                            <a rel="nofollow" href="javascript:" class="pinterest" target="_blank">pinterest</a>
                        </li>
                        <li>
                            <a rel="nofollow" href="javascript:" class="email" target="_blank">email</a>
                        </li>
                    </ul>
                </div>
                <div class="footer-links_other">
                    <h5>Customer Care</h5>
                    <ul>
                        <li>
                            <a href="javascript:">Contact Us</a>
                        </li>
                        <li>
                            <a href="javascript:">Product Labels</a>
                        </li>
                        <li>
                            <a href="javascript:">Locations</a>
                        </li>
                        <li>
                            <a href="javascript:">FAQs</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="footer-copyrights">
                <p>© 2019 Ses Team</p>
            </div>
            <div class="footer-terms">
                <a href="javascript:">Terms of Use</a>
                |
                <a href="javascript:">Privacy Policy</a>
                |
                <a href="javascript:">Site Map</a>
            </div>
        </div>
    </div>
</footer>

{{--<script src="main.js"></script>--}}
</body>
</html>
