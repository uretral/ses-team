<section>
    <div>
        <div class="slider">
            <div class="slider-box">
                <h2>Common Pests</h2>
                <p>We Know About Pests, You Can Too. Visit our Pest
                    <a href="javascript:">Library</a>
                    for information on the habits and habitats of some of the most common pests.
                </p>
                <div id="pests_slider"></div>
            </div>

        </div>
    </div>
</section>
