<section>
    <div class="cite">
        <div class="cite-box">
            <h2>{!! $data['cite_heading'] !!}</h2>
            <cite>
                {!! $data['cite_text'] !!}
            </cite>
        </div>
    </div>
</section>
