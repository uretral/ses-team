<section>
    <div class="zip">
        <div class="zip-box ">
            <span>Найдите ваш регион</span>
            <div class="communication-callback_col">
                <label>
                    <input class="region-search" type="text" placeholder="Ваш регион..."/>
                    <button class="region-sbt"><b>Да</b></button>
                </label>
                <ul class="regions-list"></ul>
            </div>
            <span>Или позвоните: <em>844-514-3974</em></span>
        </div>
    </div>
</section>
