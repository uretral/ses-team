<section>
    <div class="half">
        <div class="half-bg">
            <img src="../img/guarantee.jpg" alt=""/>
        </div>
        <div class="half-items">
            <div class="half-item"></div>
            <div class="half-item covered">
                <div class="txt">
                    <h2>Мы принесем в ваш дом комфорт и спокойствие.</h2>
                    <ul>
                        <li>
                            <a href="javascript:">30-дневная гарантия возврата денег</a>
                        </li>
                        <li>
                            <a href="javascript:">Если вредители появятся, SESTEAM приедет без дополнительной оплаты
                            </a>
                        </li>
                        <li>
                            <a href="javascript:">Если мы не можем решить вашу проблему с вредителями, мы вернем вам последний платеж за обслуживание, пока вы являетесь нашим клиентом
                            </a>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</section>
