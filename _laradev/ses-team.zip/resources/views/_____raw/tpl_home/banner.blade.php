<section>
    <div class="wide banner">
        <div class="wide-box origin">
            <img src="/img/banners/main-banner.jpg" alt="banner"/>
            <div class="banner-slogan">
                <cite>
                    <span>Контроль, устранение </span> <span>и предотвращение проблем с вредителями <sup>®</sup></span>
                </cite>
            </div>
        </div>
    </div>
</section>
