<div class="feedback">
    <form action="javascript:" class="feedback-form">
        <h3>Подпишитесь на наши новости</h3>
        <input type="text" placeholder="ваш email"/>
        <button><em>отправить</em></button>
    </form>
</div>
