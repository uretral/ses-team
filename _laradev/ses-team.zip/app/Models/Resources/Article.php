<?php

namespace App\Models\Resources;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    protected $table = 'resource_articles';


/*    public static function block($data,$b){
        return view('test.index',[
            'data' => $data->helpers,
            'backend' => $b
        ]);
    }*/


}
