<?php

namespace App\Models\Resources;

use Illuminate\Database\Eloquent\Model;

class Sticker extends Model
{
    protected $table = 'resource_stickers';
}
