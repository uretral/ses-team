<?php

namespace App\Models\Resources;

use Illuminate\Database\Eloquent\Model;

class News extends Model
{
    protected $table = 'resource_news';
}
