<?php

namespace App\Models\Mail;

use Illuminate\Database\Eloquent\Model;

class Send extends Model
{
    protected $table = 'mail';
}
